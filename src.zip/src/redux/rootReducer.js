import { combineReducers } from 'redux'
import userReducers from './userAction/reducer'
import foodReducer from './Food/foodReducer'

const rootReducer = combineReducers({
  data: userReducers,
  foodData: foodReducer,
})

export default rootReducer
