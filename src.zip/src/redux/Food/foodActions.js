import axios from 'axios'
import * as types from './foodActionType'

export const foodGetUser = (food) => {
  return {
    type: types.FOOD_GET_USERS,
    payload: food,
  }
}

export const foodGetRequest = () => {
  return {
    type: types.FOOD_GET_REQUEST,
  }
}

export const foodGetFailure = () => {
  return {
    type: types.FOOD_GET_FAILURE,
  }
}

export const loadFoodDetails = () => {
  return function (dispatch) {
    dispatch(foodGetRequest)
    axios
      .get(`${process.env.REACT_APP_API_FOOD}`)
      .then((res) => {
        const some = res.data
        console.log(some)
        dispatch(foodGetUser(some))
      })
      .catch((err) => {
        const errorMsg = err.message
        dispatch(foodGetFailure(errorMsg))
      })
  }
}
