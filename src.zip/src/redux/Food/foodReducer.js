import * as types from './foodActionType'
const initialState = {
  food: [],
  fd: {},
  loading: false,
}

const foodReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.FOOD_GET_REQUEST:
      return {
        ...state,
        loading: true,
      }
    case types.FOOD_GET_USERS:
      return {
        loading: false,
        food: action.payload,
        error: '',
      }
    case types.FOOD_GET_FAILURE:
      return {
        loading: false,
        food: [],
        error: action.payload,
      }
    default:
      return state
  }
}
export default foodReducer
