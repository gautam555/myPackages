import * as types from './actionType'
const initialState = {
  users: [],
  user: {},
  loading: false,
}
const userReducers = (state = initialState, action) => {
  switch (action.type) {
    case types.GET_REQUEST:
      return {
        ...state,
        loading: true,
      }
    case types.GET_USERS:
      return {
        loading: false,
        users: action.payload,
        error: '',
      }
    case types.GET_SINGLE_USER:
      return {
        ...state,
        loading: false,
        user: action.payload,
      }
    case types.UPDATE_USER:
      return {
        ...state,
        loading: false,
        user: action.payload,
      }

    case types.GET_FAILURE:
      return {
        loading: false,
        users: [],
        error: action.payload,
      }
    case types.DELETE_USER:
      return {
        ...state,
        loading: false,
      }
    default:
      return state
  }
}

export default userReducers
