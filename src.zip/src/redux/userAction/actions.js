import axios from 'axios'
import * as types from './actionType'

export const getRequest = () => {
  return {
    type: types.GET_REQUEST,
  }
}

export const getFailure = (error) => {
  return {
    type: types.GET_FAILURE,
    payload: error,
  }
}

export const getUsers = (users) => {
  return {
    type: types.GET_USERS,
    payload: users,
  }
}

export const getUser = (user) => {
  return {
    type: types.GET_SINGLE_USER,
    payload: user,
  }
}
export const addedUser = (user) => {
  return {
    type: types.ADD_USER,
    payload: user,
  }
}

export const userUpdated = (user) => {
  return {
    type: types.UPDATE_USER,
    payload: user,
  }
}

const userDeleted = () => {
  return {
    type: types.DELETE_USER,
  }
}
export const loadUsers = () => {
  return function (dispatch) {
    dispatch(getRequest)
    axios
      //.get(`${process.env.REACT_APP_API}`)
      .get(`${process.env.REACT_APP_API}`)
      .then((res) => {
        const some = res.data
        dispatch(getUsers(some))
      })
      .catch((err) => {
        const errormsg = err.message
        dispatch(getFailure(errormsg))
      })
  }
}

export const deleteUsers = (id) => {
  return function (dispatch) {
    axios
      .delete(`${process.env.REACT_APP_API}/${id}`)
      .then((res) => {
        console.log('res', res)
        dispatch(userDeleted(res))
        dispatch(loadUsers())
      })
      .catch((err) => {
        console.log(err)
      })
  }
}

export const addUsers = (user) => {
  return function (dispatch) {
    axios
      .post(`${process.env.REACT_APP_API}`, user)
      .then((resp) => {
        console.log('resp', resp)
        dispatch(addedUser())
        dispatch(loadUsers())
      })
      .catch((err) => {
        console.log(err)
      })
  }
}

export const getSingleUser = (id) => {
  return function (dispatch) {
    axios
      .get(`${process.env.REACT_APP_API}/${id}`)
      .then((res) => {
        console.log('res', res)
        dispatch(getUser(res.data))
      })
      .catch((err) => {
        console.log(err)
      })
  }
}

export const updateUser = (user, id) => {
  return function (dispatch) {
    axios
      .put(`${process.env.REACT_APP_API}/${id}`, user)
      .then((res) => {
        console.log('res', res)
        dispatch(userUpdated(res.data))
      })
      .catch((err) => {
        console.log(err)
      })
  }
}
