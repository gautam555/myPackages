import './App.css'
import { Switch, Route } from 'react-router-dom'
import Home from './pages/Home'
import { AddUser } from './pages/AddUser'
import EditUser from './pages/EditUser'
import Login from './pages/LoginModule/Login'
import Signup from './pages/LoginModule/Signup'
import SignupContainer from './pages/Containers/SignupContainer'

function App() {
  return (
    <div className="App">
      <Switch>
        {/* <Route exact path="/" component={SignupContainer}></Route>
        <Route exact path="/signup" component={Signup}></Route>
        <Route exact path="/login" component={Login}></Route> */}
        <Route exact path="/" component={Home}></Route>
        <Route exact path="/adduser" component={AddUser}></Route>
        <Route exact path="/edituser/:id" component={EditUser}></Route>
      </Switch>
    </div>
  )
}

export default App
