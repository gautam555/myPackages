import { Button, Grid, Paper, TextField, Typography } from '@material-ui/core'
import React, { useState } from 'react'
import { Avatar } from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import Checkbox from '@material-ui/core/Checkbox'
import { Link } from '@material-ui/core'
import { useHistory } from 'react-router'

export const Login = ({ handleChange }) => {
  const [state, setState] = useState({
    userName: '',
    password: '',
  })
  const [error, setError] = useState('')
  const { userName, password } = state
  const history = useHistory()
  const paperStyle = {
    width: 300,
    height: '53vh',
    padding: 20,
    margin: '0px auto',
  }
  const avtarStyle = {
    backgroundColor: '#68903d',
  }
  const btnStyle = {
    margin: '8px 0px',
  }
  const handeInputChange = (e) => {
    const { name, value } = e.target
    setState({ ...state, [name]: value })
  }
  const loginSubmit = (e) => {
    e.preventDefault()
    if (!userName || !password) {
      setError('Please enter login details')
    } else {
      history.push('/home')
    }
  }
  return (
    <div>
      <Grid>
        <Paper style={paperStyle}>
          <Grid align="center">
            {' '}
            <Avatar style={avtarStyle}>
              <LockOutlinedIcon />
            </Avatar>
            <h2> Sign in </h2>
          </Grid>
          {error && <h3 style={{ color: 'red' }}>{error}</h3>}
          <form onSubmit={loginSubmit}>
            <TextField
              label="Username"
              placeholder="Enter user name"
              fullWidth
              value={userName}
              name="userName"
              onChange={handeInputChange}
            />
            <TextField
              label="Password"
              placeholder="Enter user Password"
              type="password"
              fullWidth
              value={password}
              name="password"
              onChange={handeInputChange}
            />
            <FormControlLabel
              control={<Checkbox name="checkedB" color="primary" />}
              label="Remember me"
            />
            <Button
              fullWidth
              variant="contained"
              style={btnStyle}
              type="submit"
              color="primary"
            >
              Sign in
            </Button>
          </form>
          <Typography>
            <Link href="#">Forgot password ?</Link>
          </Typography>
          <Typography>
            {' '}
            Do you have an account
            <Link href="#" onClick={() => handleChange('event', 1)}>
              Sign up{' '}
            </Link>
          </Typography>
        </Paper>
      </Grid>
    </div>
  )
}

export default Login
