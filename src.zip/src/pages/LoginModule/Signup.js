import { Button, Grid, Paper, TextField, Typography } from '@material-ui/core'
import AddCircleOutlineOutlinedIcon from '@material-ui/icons/AddCircleOutlineOutlined'
import React from 'react'
import { Avatar } from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined'
import Checkbox from '@material-ui/core/Checkbox'
import { Link } from '@material-ui/core'
import Radio from '@material-ui/core/Radio'
import RadioGroup from '@material-ui/core/RadioGroup'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import FormControl from '@material-ui/core/FormControl'
import FormLabel from '@material-ui/core/FormLabel'

export const Signup = () => {
  const paperStyle = {
    padding: 20,
    width: 300,
    height: '53vh',
    margin: '0px auto',
  }
  const headerStyle = {
    margin: 0,
  }
  const avtarStyle = {
    backgroundColor: '#68903d',
  }
  return (
    <div>
      <Grid>
        <Paper style={paperStyle}>
          <Grid align="center">
            {' '}
            <Avatar style={avtarStyle}>
              <AddCircleOutlineOutlinedIcon />
            </Avatar>
            <h2 style={headerStyle}>Sign up</h2>
            <Typography variant="caption" gutterBottom>
              Please fill this form to create an account !
            </Typography>
          </Grid>
          <form>
            <TextField
              label="Name"
              placeholder="Please enter your name"
              fullWidth
            />
            <TextField label="Email" fullWidth />
            <FormControl component="fieldset" style={{ marginTop: 5 }}>
              <FormLabel component="legend">Gender</FormLabel>
              <RadioGroup
                style={{ display: 'initial' }}
                aria-label="gender"
                name="gender"
              >
                <FormControlLabel
                  value="female"
                  control={<Radio />}
                  label="Female"
                />
                <FormControlLabel
                  value="male"
                  control={<Radio />}
                  label="Male"
                />
              </RadioGroup>
            </FormControl>
            <TextField label="Phone number" fullWidth />
            <TextField label="Password" fullWidth />
            <TextField label="Confirm Password" fullWidth />
            <FormControlLabel
              control={<Checkbox name="checkedB" color="secondary" />}
              label="I accept the term and condition"
            />
            <Button variant="contained" color="primary" type="submit">
              Sign up
            </Button>
          </form>
        </Paper>
      </Grid>
    </div>
  )
}

export default Signup
