import React, { useEffect, useState } from 'react'
import { withStyles, makeStyles } from '@material-ui/core/styles'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableContainer from '@material-ui/core/TableContainer'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import TablePagination from '@material-ui/core/TablePagination'
import TableFooter from '@material-ui/core/TableFooter'
import Paper from '@material-ui/core/Paper'
import { useDispatch, useSelector } from 'react-redux'
import { loadUsers } from '../redux/userAction/actions'
import { deleteUsers } from '../redux/userAction/actions'
import Button from '@material-ui/core/Button'
import ButtonGroup from '@material-ui/core/ButtonGroup'
import { useHistory } from 'react-router-dom'
import { red } from '@material-ui/core/colors'
import { Card } from '@material-ui/core'
import DataCard from './DataCard'

const usebuttonStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    marginTop: '20px',
    alignItems: 'center',
    '& > *': {
      margin: theme.spacing(1),
    },
  },
}))

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell)

const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    height: 50,
  },
}))(TableRow)

const useStyles = makeStyles({
  table: {
    marginTop: 10,
    //minWidth: 900,
  },
})

export const Home = () => {
  const classes = useStyles()
  const buttonStyles = usebuttonStyles()
  const { users } = useSelector((state) => state.data)
  const [rowsPerPage, setRowsPerPage] = useState(5)
  const [page, setPage] = useState(0)
  let dispatch = useDispatch()
  let history = useHistory()

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    //console.log('abcd', event.target.value)
    setRowsPerPage(+event.target.value)
    setPage(0)
  }
  const handleDelete = (id) => {
    if (window.confirm('Are you sure want to delete the user')) {
      dispatch(deleteUsers(id))
    }
  }
  useEffect(() => {
    dispatch(loadUsers())
  }, [])
  return (
    <div>
      <div className={buttonStyles.root}>
        {' '}
        <Button
          variant="contained"
          color="primary"
          onClick={() => history.push('/adduser')}
        >
          Add user
        </Button>
      </div>
      <div>
        <TableContainer style={{ width: '50%' }}>
          <Table
            style={{ width: '50%' }}
            className={classes.table}
            aria-label="customized table"
          >
            <TableHead>
              <TableRow>
                <StyledTableCell>Name</StyledTableCell>
                <StyledTableCell align="center">Email</StyledTableCell>
                <StyledTableCell align="center">Contact</StyledTableCell>
                <StyledTableCell align="center">Address</StyledTableCell>
                <StyledTableCell align="center">Action</StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((user) => (
                  <StyledTableRow style={{ height: 30 }} key={user.id}>
                    <StyledTableCell component="th" scope="row">
                      {user.name}
                    </StyledTableCell>
                    <StyledTableCell align="center">
                      {user.email}
                    </StyledTableCell>
                    <StyledTableCell align="center">
                      {user.contact}
                    </StyledTableCell>
                    <StyledTableCell align="center">
                      {user.address}
                    </StyledTableCell>
                    <StyledTableCell align="center">
                      <div className={buttonStyles.root}>
                        <ButtonGroup
                          variant="contained"
                          aria-label="contained primary button group"
                        >
                          <Button
                            style={{ marginRight: '5px' }}
                            color="secondary"
                            onClick={() => handleDelete(user.id)}
                          >
                            Delete
                          </Button>
                          <Button
                            color="primary"
                            onClick={() => history.push(`/edituser/${user.id}`)}
                          >
                            Edit
                          </Button>
                        </ButtonGroup>
                      </div>
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TablePagination
                  rowsPerPageOptions={[5, 10, 25]}
                  colSpan={3}
                  count={users.length}
                  rowsPerPage={5}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />
              </TableRow>
            </TableFooter>
          </Table>
        </TableContainer>
        <div
          style={{
            position: 'relative',
            width: '50%',
            height: '800px',
            float: 'right',
            bottom: '660px',
          }}
        >
          {<DataCard></DataCard>}
        </div>
      </div>
    </div>
  )
}

export default Home
